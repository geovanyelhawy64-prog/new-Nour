class SearchNormalizer {
  SearchNormalizer._();

  static final RegExp _tashkeelRegex = RegExp(r'[\u064B-\u065F\u0670]');
  static final RegExp _tatweelRegex = RegExp(r'\u0640');
  static final RegExp _extraSpacesRegex = RegExp(r'\s+');

  /// تطبيع النص العربي للبحث السريع والدقيق
  static String normalize(String input) {
    if (input.isEmpty) return '';

    var result = input.trim();

    // 1. إزالة التشكيل
    result = result.replaceAll(_tashkeelRegex, '');

    // 2. إزالة التطويل (ـ)
    result = result.replaceAll(_tatweelRegex, '');

    // 3. توحيد الهمزات والألف
    result = result
        .replaceAll('أ', 'ا')
        .replaceAll('إ', 'ا')
        .replaceAll('آ', 'ا')
        .replaceAll('ء', '')
        .replaceAll('ؤ', 'و')
        .replaceAll('ئ', 'ي');

    // 4. توحيد التاء المربوطة والهاء
    result = result.replaceAll('ة', 'ه');

    // 5. توحيد الألف المقصورة والياء
    result = result.replaceAll('ى', 'ي');

    // 6. توحيد المسافات
    result = result.replaceAll(_extraSpacesRegex, ' ');

    return result.toLowerCase();
  }

  /// هل النص يحتوي على الكلمة المفتاحية بعد التطبيع
  static bool matches(String source, String query) {
    if (query.isEmpty) return true;
    final normalizedSource = normalize(source);
    final normalizedQuery = normalize(query);
    return normalizedSource.contains(normalizedQuery);
  }
}
